//#-hidden-code
//
//  Created by kingcos on 29/03/2018.
//  Copyright © 2018 kingcos. All rights reserved.
//
//#-end-hidden-code
/*
 Hello again!
 
 AR (Augment Reality) is very hot, since Apple announced the ARKit at WWDC. I think AR give us imagination to think different. We can use it to find a diffefent world.
 
 You will see a little plus button in middle of right area. And the titles is refreshing results!
 
 Yes! You can use your camera to detect the digit. Because of time is limited, I trained just hundreds of images. The effects may not perfect.
 
 When the camera catch your digit, you can touch the plus button, then a label of the result will attach your digit!
 
 It integrate CoreML, ARKit, Vision, and SceneKit!
 
 I think this is a great example for kids to detect their world or any other use cases. The AR will expand our view to see a new world. The ML will let the machine more clever to help us. And we, will open a new world!
 
 */
